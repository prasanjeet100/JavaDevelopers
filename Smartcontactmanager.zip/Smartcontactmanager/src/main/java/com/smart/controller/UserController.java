package com.smart.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.smart.entyties.Contact;
import com.smart.entyties.User;
import com.smart.helper.Message;
import com.smart.repository.ContactRepository;
import com.smart.repository.UserRepository;
import com.smart.response.APIStatus;

import net.sf.json.JSONObject;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ContactRepository contactRepository;
	
	@ModelAttribute
	public void commonData(Model model, Principal princiapal)
	{
		String username = princiapal.getName();
		User user = userRepository.getUserByUserName(username);
		model.addAttribute("baseuser",user);
		System.out.println(user);
		
	}
	
	@GetMapping("/index")
	public String userDashboard(Model model)
	{
		model.addAttribute("title","home dashboard");
		return "/normal/userdashboard";
	}
	
	@GetMapping("/add_contact")
	public String addContact(Model model)
	{
		model.addAttribute("title","add contact form");
		Contact contact=new Contact(); 
		model.addAttribute("contact",contact);
		return "normal/add_contact";
	}

	@PostMapping("/process")
    public String processContact(@Valid @ModelAttribute Contact contact,@RequestParam("profileimg") MultipartFile file, BindingResult result,Model model, Principal principal,HttpSession session) 
    {
		/*if(result.hasErrors())
		{
			System.out.println(result);
		}*/
		try
		{
			String name = principal.getName();
			System.out.println(name);
			User user = userRepository.getUserByUserName(name);
			
				if(file.isEmpty())
				{
					System.out.println("file is Empty");
					contact.setImage("contact.png");
				}
				else
				{
				contact.setImage(file.getOriginalFilename());
				File saveFile=new ClassPathResource("static/img").getFile();
				Path paths=Paths.get(saveFile.getAbsolutePath()+File.separator+file.getOriginalFilename());
				Files.copy(file.getInputStream(), paths, StandardCopyOption.REPLACE_EXISTING);
				System.out.println("image is uploaded");
				}

				user.getContact().add(contact);		
	        	contact.setUser(user);
		        this.userRepository.save(user);
		
		       
		        session.setAttribute("message", new Message("Added Successfully","success"));
		        
		       // model.addAttribute("contact",contact);
    
				}
				catch(Exception e)
				{
					 session.setAttribute("message", new Message("Something going wrong","primary"));
					System.out.println(e);
					e.printStackTrace();
				}
				return "normal/add_contact";
		    }
		  
			//show user 
	//per page
	//current page
			@GetMapping("/show_user/{page}")
			public String showUser(@PathVariable("page") Integer page, Model model,Principal principle)
			{
				String name = principle.getName();
				User user = this.userRepository.getUserByUserName(name);
				System.out.println(page);
				//per page
				//current page
				Pageable pageable = PageRequest.of(page, 5);
				
			    Page<Contact> contact = this.contactRepository.findContactByUser(user.getId(),pageable);
				model.addAttribute("contact",contact);
				model.addAttribute("currentpage", page);
				model.addAttribute("totalpages",contact.getTotalPages());
				return "normal/show_user";
			}
			
			@GetMapping("/contactprofile/{id}")
			public String showContactProfile(@PathVariable("id") Integer id, Model model,Principal principle)
			{
				Optional<Contact> optionContact = contactRepository.findById(id);
				Contact contact = optionContact.get();
				
				String name = principle.getName();
				User user = userRepository.getUserByUserName(name);
				//see only user data
				if(user.getId()==contact.getUser().getId())
				{
					model.addAttribute("contact",contact);	
				}
				
				return "normal/contactprofile";
			}
			
			//for delete
			@GetMapping("/delete/{id}")
			public String deleteContact(@PathVariable("id") Integer id,Model model,HttpSession session,Principal princiapl)
			{
				
				Optional<Contact> contactOptional = contactRepository.findById(id) ;
				Contact contact = contactOptional.get();
				
				System.out.println(contact.getcId());
				
				//contact.setUser(null);
				//check assignment
				//this.contactRepository.delete(contact);
				
				User user = userRepository.getUserByUserName(princiapl.getName());
				user.getContact().remove(contact);
				this.userRepository.save(user);
				
				System.out.println("deleted successfully");
				session.setAttribute("message", new Message("contact deleted successfully...","success"));
				
				return "redirect:/user/show_user/0";
			}
			
			@PostMapping("/update-contact/{cid}")
			public String updateForm(@PathVariable("cid")  Integer cid,Model model)
			{
				model.addAttribute("title","update Form");
				Optional<Contact> findById = contactRepository.findById(cid);
				Contact contact = findById.get();
				model.addAttribute("contact",contact);
				System.out.println(cid);
				return "normal/update-contact";
			}
			
			@PostMapping("/process-update")
			public String updateHendler(@ModelAttribute Contact contact
					,@RequestParam("profileimg") MultipartFile file,Model model,HttpSession session,
					Principal principal)
			{
				Optional<Contact> oldcondetails = contactRepository.findById(contact.getcId());
				Contact contactold = oldcondetails.get();
				try
				{
					
					if(!file.isEmpty())
					{
						
						//file work
						//rewrite
						//delete old photo
						File deleteFile=new ClassPathResource("static/img").getFile();
						File file1=new File(deleteFile,contactold.getImage());
						file1.delete();
						//update new photo
						
						File saveFile=new ClassPathResource("static/img").getFile();
						Path paths=Paths.get(saveFile.getAbsolutePath()+File.separator+file.getOriginalFilename());
						Files.copy(file.getInputStream(), paths, StandardCopyOption.REPLACE_EXISTING);
						contact.setImage(file.getOriginalFilename());
						
					}
					else
					{
						contact.setImage(contactold.getImage());
					}
					
					String name = principal.getName();
					User user = userRepository.getUserByUserName(name);
					contact.setUser(user);
					this.contactRepository.save(contact);
					session.setAttribute("message", new Message("updated successfully","success"));
					
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				System.out.println(contact.getName());
				return "redirect:/user/contactprofile/"+contact.getcId();
			}
			//ajax controller
			@GetMapping("/userprofile")
			public String userProfile()
			{
				return "normal/userprofile";
			}
			
			
   }

