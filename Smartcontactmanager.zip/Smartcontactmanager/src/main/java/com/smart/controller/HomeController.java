package com.smart.controller;

import java.security.Principal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.smart.entyties.User;
import com.smart.helper.Message;
import com.smart.repository.ContactRepository;
import com.smart.repository.UserRepository;
import com.smart.services.UserService;

import net.sf.json.JSONObject;

import com.smart.response.*;
@Controller
public class HomeController {

	@Autowired
	public BCryptPasswordEncoder passwordEncoder;
	@Autowired
	public UserService userService;
	@Autowired
	UserRepository userRepository;
	@Autowired
	ContactRepository contactRepository;
	@GetMapping("/")
	public String test(Model model)
	{
	return "home";
	}
	@GetMapping("/signup")
	public String signup(Model model)
	{
		
		User user=new User();
		model.addAttribute("user",user);
		return "signup";
	}
	@PostMapping("/signupprocess")
	public String registerForm(@Valid @ModelAttribute User user, BindingResult result1,@RequestParam(value="agreement", defaultValue="false") boolean agreement, Model model,HttpSession session)
	{
		
	
			try
		{
			if(!agreement)
			{
				//System.out.println("you have not agreed the term & condition");
				throw new Exception("you have not agreed the term & condition");
			}
			if(result1.hasErrors())
			{
				System.out.println("error occured"+result1.toString());
				model.addAttribute("user",user);
				return "signup";
			}
			user.setRole("ROLE_USER");
			user.setEnabled(true);
			user.setImgUrl("pc.jpg");
			String password = user.getPassword();
			System.out.println(password);
			user.setPassword(passwordEncoder.encode(password));
			
			System.out.println(user);
			System.out.println(agreement);
			User result = userService.save(user);
			model.addAttribute("user",user);
			session.setAttribute("message", new Message("Registerd Successfully!!","alert-success"));
			return "signup";
		}
		catch(Exception e)
		{
			e.printStackTrace();
			model.addAttribute("user",user);
			session.setAttribute("message", new Message("something went wrong !!"+e.getMessage(),"alert-danger"));
			return "signup";
		}
		
	}
	
	@GetMapping("/about")
    public String about()
	{
		return "about";
	}
	
	@GetMapping("/signin")
	public String signin()
	{
		return "login";
	}
	
	//for ajax
	@GetMapping("/ajaxdemo")
	public String view()
	{
		return "ajaxdemo";
	}
	
	/*@GetMapping("/findalluser")
	public ResponseEntity<String> ajaxdemo()
	{
		List<User> findAll = userRepository.findAll();
		 return new ResponseEntity ("ok it good"+findAll, HttpStatus.OK);
	}*/
	
	@GetMapping("/findalluser")
	public String users(HttpServletRequest request,Principal principal) throws JsonProcessingException 
	{
		Map<String, String> map=new HashMap<String, String>();
		map.put("ravi", "sunil");
		
		ObjectMapper mapper = new ObjectMapper();
		JSONObject response = new JSONObject();
		//	response.put("name", "prasanjeet");
			response.put("data", mapper.writeValueAsString(map));
			return response.toString();
		 
	}
}
