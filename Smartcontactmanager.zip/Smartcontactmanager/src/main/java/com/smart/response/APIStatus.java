package com.smart.response;

public enum APIStatus {
	SUCCESS,
	FAIL
}
