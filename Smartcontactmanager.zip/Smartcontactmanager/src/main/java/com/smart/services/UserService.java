package com.smart.services;

import com.smart.entyties.User;

public interface UserService {

	public User save(User user);
}
