package com.smart.entyties;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.transaction.Transactional;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Table(name="CONTACT", schema="smart")
public class Contact {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer cId;
	
	
     //@NotBlank(message = "Folder name is mandatory.")
	//@Size(min=3,max=12, message="name must be between 3 to 10 character")
	private String name;
	
	//@NotBlank(message= "second name must not be blank")
	//@Size(min=3,max=12, message="second name must be between 3 to 10 character")
	private String secondNm;
	
	//@NotBlank(message="work must not be blank")
	//@Size(min=10,max=50, message="work must be between 10 to 50 character")
	private String work;
	
	//@Email
	private String email;
	
	//@NotBlank(message="phone number must not be blank")
	//@Size(min=10,max=10, message="phone number should be 10 number")
	private String phone;
	
	//@NotBlank
	private String image;
	
	//@NotBlank(message="discription must not be blank")
	//@Size(min=10,max=50, message="discription must be between 10 to 50 character")
	@Column(length=50000)
	private String description;
	
	@ManyToOne
	private User user;
	
	public Contact() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getcId() {
		return cId;
	}
	public void setcId(Integer cId) {
		this.cId = cId;
	}
	@Transactional
	public String getName() {
		return name;
	}
	
	@Transactional
	public void setName(String name) {
		this.name = name;
	}
	public String getSecondNm() {
		return secondNm;
	}
	public void setSecondNm(String secondNm) {
		this.secondNm = secondNm;
	}
	public String getWork() {
		return work;
	}
	public void setWork(String work) {
		this.work = work;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public boolean equals(Object obj)
	{
		return this.cId==((Contact)obj).getcId();
	}
	/*@Override
	public String toString() {
		return "Contact [cId=" + cId + ", name=" + name + ", secondNm=" + secondNm + ", work=" + work + ", email="
				+ email + ", phone=" + phone + ", image=" + image + ", description=" + description + ", user=" + user
				+ "]";
	}*/
	
}
